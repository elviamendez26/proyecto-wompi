import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-pagos',
  templateUrl: './grid-pagos.component.html',
  styleUrls: ['./grid-pagos.component.scss']
})
export class GridPagosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
